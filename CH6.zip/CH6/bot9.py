import re  # นำเข้าไลบรารี Regular Expressions สำหรับการจับคู่ข้อความ
import random  # นำเข้าไลบรารี random สำหรับสุ่มเลือกคำตอบ

# พจนานุกรม rules ที่เก็บรูปแบบคำถาม (ใช้ RegEx) และคำตอบที่เป็นไปได้
rules = {
    'do you think (.*)': [
        'if {0}? Absolutely.',  # ตัวอย่างคำตอบที่ใช้ RegEx
        'No chance'],
    'do you remember (.*)': [
        'Did you think I would forget {0}',
        "Why haven't you been able to forget {0}",
        'What about {0}',
        'Yes .. and?'],
    'I want (.*)': [
        'What would it mean if you got {0}',
        'Why do you want {0}',
        "What's stopping you from getting {0}"],
    'if (.*)': [
        "Do you really think it's likely that {0}",
        'Do you wish that {0}',
        'What do you think about {0}',
        'Really--if {0}']
}

# ฟังก์ชัน match_rule สำหรับจับคู่ข้อความและตอบกลับ
def match_rule(rules, message):
    response, phrase = "default", None  # กำหนดค่าเริ่มต้นสำหรับ response และ phrase
   
    # วนลูปเพื่อหากฎที่ตรงกับข้อความจากผู้ใช้
    for pattern, responses in rules.items():
        # สร้าง match object เพื่อตรวจสอบว่าข้อความตรงกับกฎหรือไม่
        match = re.search(pattern, message)
        if match is not None:  # ถ้ามีการจับคู่สำเร็จ
            # เลือกคำตอบแบบสุ่มจาก responses
            response = random.choice(responses)
            if '{0}' in response:  # ถ้าคำตอบมี {0} อยู่ จะใช้ match.group(1) แทน
                phrase = match.group(1)
    # คืนค่าคำตอบที่ถูกปรับปรุงตามที่จับคู่ได้
    return response.format(phrase)

# วนลูปเพื่อรับข้อความจากผู้ใช้และตอบกลับ
while True:
    # รับข้อความจากผู้ใช้
    user_input = input("USER : ")
   
    # ตรวจสอบว่าผู้ใช้พิมพ์ "bye" เพื่อจบการสนทนา
    if user_input.lower() == "bye":
        print("BOT : Goodbye!")
        break
   
    # ใช้ฟังก์ชัน match_rule เพื่อหาคำตอบของบอท
    response = match_rule(rules, user_input)
   
    # แสดงผลคำตอบของบอท
    print(f"BOT : {response}")
