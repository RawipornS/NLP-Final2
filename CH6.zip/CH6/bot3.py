# สร้างเทมเพลตสำหรับข้อความบอทและผู้ใช้
bot_template = "BOT : {0}"  # เทมเพลตสำหรับการแสดงผลข้อความของบอท
user_template = "USER : {0}"  # เทมเพลตสำหรับการแสดงผลข้อความของผู้ใช้

# พจนานุกรม responses สำหรับคำถามที่เกี่ยวกับสภาพอากาศ
responses = { "what's today's weather?": "it's {} today" }  # ใช้ {} เพื่อใส่ค่าของสภาพอากาศในข้อความ

# สร้างตัวแปร weather_today สำหรับเก็บข้อมูลสภาพอากาศของวันนี้
weather_today = "cloudy"  # ค่าเริ่มต้นของสภาพอากาศวันนี้คือ 'cloudy'

# ฟังก์ชัน respond สำหรับตอบกลับข้อความของผู้ใช้
def respond(message):
    if message in responses:  # ตรวจสอบว่าข้อความผู้ใช้ตรงกับคำถามใน responses หรือไม่
        return responses[message].format(weather_today)  # ใช้ .format() เพื่อใส่ค่าของ weather_today ลงในข้อความตอบกลับ

# เรียกฟังก์ชัน respond ด้วยคำถาม "what's today's weather?" เพื่อตรวจสอบการทำงาน
respond("what's today's weather?")

# ฟังก์ชัน send_message สำหรับรับข้อความผู้ใช้และตอบกลับ
def send_message():
    while True:  # วนลูปเพื่อให้ผู้ใช้สามารถส่งข้อความได้หลายครั้ง
        message = input("USER: ")  # รับข้อความจากผู้ใช้
        
        # ถ้าผู้ใช้พิมพ์ 'bye' บอทจะกล่าวลาและจบการสนทนา
        if message.lower() == 'bye':  # ตรวจสอบว่าผู้ใช้พิมพ์ 'bye' หรือไม่
            print("BOT: Goodbye!")  # แสดงข้อความลาจากบอท
            break  # ออกจากลูป

        response = respond(message)  # เรียกใช้ฟังก์ชัน respond เพื่อสร้างคำตอบจากข้อความผู้ใช้

        print(bot_template.format(response))  # แสดงผลข้อความบอทโดยใช้เทมเพลต bot_template

# เรียกฟังก์ชัน send_message เพื่อเริ่มการสนทนากับผู้ใช้
send_message()
