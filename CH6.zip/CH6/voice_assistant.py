import pyttsx3  # นำเข้าไลบรารีสำหรับการแปลงข้อความเป็นเสียงพูด (text-to-speech)
import webbrowser  # นำเข้าไลบรารีสำหรับเปิดเว็บเบราว์เซอร์
import datetime  # นำเข้าไลบรารีสำหรับการจัดการวันและเวลา
import wikipedia  # นำเข้าไลบรารีสำหรับค้นหาข้อมูลจาก Wikipedia

# ฟังก์ชัน assistant() ทำหน้าที่แปลงข้อความเป็นเสียงพูด
def assistant(audio):
    engine = pyttsx3.init()  # เริ่มต้น pyttsx3 engine
    voices = engine.getProperty('voices')  # ดึงข้อมูลเสียงที่มีในระบบ
    engine.setProperty('voice', voices[1].id)  # ตั้งค่าเสียงเป็นเสียงที่ 2 (เสียงผู้หญิง)
    engine.say(audio)  # ให้บอทพูดข้อความที่ส่งเข้าไปใน audio
    engine.runAndWait()  # รอให้เสียงพูดทำงานเสร็จสิ้นก่อนดำเนินการต่อ

# ฟังก์ชัน greeting() ให้บอทกล่าวทักทายผู้ใช้
def greeting():
    assistant("Hello, I am your Virtual Assistant. How Can I Help You")  # ทักทายผู้ใช้

# ฟังก์ชัน core_code() เรียกใช้การทักทายเมื่อเริ่มโปรแกรม
def core_code():
    greeting()  # เรียกฟังก์ชัน greeting()

# ฟังก์ชัน theDay() ใช้สำหรับบอกวันในสัปดาห์
def theDay():
    day = datetime.datetime.today().weekday() + 1  # ดึงข้อมูลวันในสัปดาห์ (0 คือ Monday, +1 เพื่อทำให้เริ่มที่ 1)
    Day_dict = {  # กำหนดพจนานุกรมเพื่อแปลงค่าตัวเลขเป็นวัน
        1: 'Monday', 2: 'Tuesday',
        3: 'Wednesday', 4: 'Thursday',
        5: 'Friday', 6: 'Saturday',
        7: 'Sunday'
    }
    if day in Day_dict.keys():  # ตรวจสอบว่าวันที่ดึงมาอยู่ในพจนานุกรมหรือไม่
        weekday = Day_dict[day]  # แปลงวันเป็นชื่อของวัน
        assistant("It's " + weekday)  # ให้บอทบอกว่าวันนี้เป็นวันอะไร

# ฟังก์ชัน theTime() ใช้สำหรับบอกเวลาในขณะนั้น
def theTime():
    time = str(datetime.datetime.now())  # ดึงข้อมูลเวลาในปัจจุบันและแปลงเป็นสตริง
    hour = time[11:13]  # ดึงเฉพาะชั่วโมงจากข้อมูลเวลา
    min = time[14:16]  # ดึงเฉพาะนาทีจากข้อมูลเวลา
    assistant("The time right now is " + hour + " hours and " + min + " minutes")  # ให้บอทบอกเวลา

# เริ่มต้นโปรแกรมด้วยการเรียกฟังก์ชัน core_code()
core_code()

# ลูปการสนทนา (Chat Loop) เพื่อรับคำสั่งจากผู้ใช้
while (True):
    # ใช้ input() เพื่อรับข้อความจากผู้ใช้ แทนการฟังเสียง
    phrase = input("You: ").lower()  # รับข้อความจากผู้ใช้และแปลงเป็นตัวพิมพ์เล็ก

    # ตรวจสอบว่าข้อความที่ผู้ใช้พิมพ์ตรงกับเงื่อนไขใดในบอท
    if "what is your name" in phrase:  # ถ้าผู้ใช้ถามชื่อบอท
        assistant("I am your nameless virtual assistant")  # ให้บอทบอกว่าไม่มีชื่อ
        continue  # ดำเนินการต่อไป
    elif "what day is it" in phrase:  # ถ้าผู้ใช้ถามว่าวันนี้วันอะไร
        theDay()  # เรียกฟังก์ชัน theDay() เพื่อบอกวัน
        continue  # ดำเนินการต่อไป
    elif "what time is it" in phrase:  # ถ้าผู้ใช้ถามเวลา
        theTime()  # เรียกฟังก์ชัน theTime() เพื่อบอกเวลา
        continue  # ดำเนินการต่อไป
    elif "open google" in phrase:  # ถ้าผู้ใช้สั่งให้เปิด Google
        assistant("Opening Google")  # ให้บอทบอกว่าจะเปิด Google
        webbrowser.open("https://www.google.com")  # เปิดเว็บ Google
        continue  # ดำเนินการต่อไป
    elif "wiki" in phrase:  # ถ้าผู้ใช้ถามข้อมูลจาก Wikipedia
        assistant("Checking Wikipedia")  # ให้บอทบอกว่าจะเช็ค Wikipedia
        phrase = phrase.replace("wiki ", "")  # ลบคำว่า "wiki " ออกจากข้อความเพื่อเหลือเฉพาะคำที่ต้องการค้นหา
        result = wikipedia.summary(phrase, sentences=4)  # ค้นหาข้อมูลจาก Wikipedia โดยสรุป 4 ประโยค
        assistant("As per Wikipedia")  # ให้บอทบอกว่าข้อมูลมาจาก Wikipedia
        assistant(result)  # ให้บอทอ่านข้อมูลที่ค้นพบจาก Wikipedia
        continue  # ดำเนินการต่อไป
    elif "search youtube for" in phrase:  # ถ้าผู้ใช้สั่งให้ค้นหาบน YouTube
        search_query = phrase.replace("search youtube for ", "")  # ลบคำว่า "search youtube for " และเหลือคำที่ต้องการค้นหา
        assistant(f"Searching YouTube for {search_query}")  # ให้บอทบอกว่าจะค้นหาบน YouTube
        webbrowser.open(f"https://www.youtube.com/results?search_query={search_query}")  # เปิด YouTube และค้นหาด้วยคำที่ผู้ใช้ระบุ
        continue  # ดำเนินการต่อไป
    elif "bye" in phrase:  # ถ้าผู้ใช้บอกลา
        assistant("Exiting. Have a Good Day")  # ให้บอทบอกลาผู้ใช้
        break  # หยุดการทำงานของลูปและจบโปรแกรม
