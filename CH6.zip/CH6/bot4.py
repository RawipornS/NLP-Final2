# สร้างเทมเพลตสำหรับข้อความบอทและผู้ใช้ เพื่อใช้ในการแสดงผล
bot_template = "BOT : {0}"  # เทมเพลตสำหรับข้อความของบอท
user_template = "USER : {0}"  # เทมเพลตสำหรับข้อความของผู้ใช้

# พจนานุกรม responses เก็บคำตอบที่หลากหลายสำหรับคำถาม "what's your name?"
responses = {
    "what's your name?": [
        "my name is EchoBot",  # คำตอบที่เป็นไปได้ 1
        "they call me EchoBot",  # คำตอบที่เป็นไปได้ 2
        "the name's Bot, EchoBot"  # คำตอบที่เป็นไปได้ 3
    ]
}

# นำเข้าไลบรารี random เพื่อเลือกคำตอบแบบสุ่มจาก responses
import random

# ฟังก์ชัน respond จะเลือกคำตอบจาก responses โดยสุ่มจากรายการคำตอบ
def respond(message):
    if message in responses:  # ตรวจสอบว่าข้อความผู้ใช้ตรงกับคำถามใน responses หรือไม่
        return random.choice(responses[message])  # คืนค่าคำตอบที่สุ่มเลือกจากรายการคำตอบที่ตรงกัน

# ทดสอบฟังก์ชัน respond ด้วยคำถาม "what's your name?" เพื่อดูว่าจะเลือกคำตอบแบบสุ่มได้อย่างถูกต้องหรือไม่
respond("what's your name?")

# ฟังก์ชัน send_message สำหรับรับข้อความจากผู้ใช้และตอบกลับโดยใช้ฟังก์ชัน respond
def send_message():
    while True:  # วนลูปเพื่อให้ผู้ใช้สามารถสนทนาได้หลายครั้ง
        message = input("USER: ")  # รับข้อความจากผู้ใช้
        
        # ตรวจสอบว่าผู้ใช้พิมพ์ 'bye' หรือไม่
        if message.lower() == 'bye':  # ถ้าผู้ใช้พิมพ์ว่า 'bye' บอทจะกล่าวลาและจบการสนทนา
            print("BOT: Goodbye!")  # แสดงข้อความลา
            break  # ออกจากลูป
        
        # เรียกใช้ฟังก์ชัน respond เพื่อหาคำตอบสำหรับข้อความผู้ใช้
        response = respond(message)
        
        # แสดงข้อความของบอท โดยใช้เทมเพลต bot_template
        print(bot_template.format(response))

# เรียกใช้ฟังก์ชัน send_message เพื่อเริ่มต้นการสนทนาระหว่างผู้ใช้และบอท
send_message()
