# ฟังก์ชัน replace_pronouns สำหรับการแทนที่สรรพนามในประโยค
def replace_pronouns(message):
    message = message.lower()  # แปลงข้อความให้เป็นตัวพิมพ์เล็กเพื่อความสม่ำเสมอในการเปรียบเทียบ
    if 'me' in message:
        # แทนที่ 'me' ด้วย 'you'
        return message.replace('me', 'you')
    if 'my' in message:
        # แทนที่ 'my' ด้วย 'your'
        return message.replace('my', 'your')
    if 'your' in message:
        # แทนที่ 'your' ด้วย 'my'
        return message.replace('your', 'my')
    if 'you' in message:
        # แทนที่ 'you' ด้วย 'me'
        return message.replace('you', 'me')
    return message  # ถ้าไม่มีการจับคู่สรรพนาม คืนค่าข้อความเดิม

# ทดสอบฟังก์ชัน replace_pronouns
print(replace_pronouns("my last birthday"))  # Output: your last birthday
print(replace_pronouns("go with me to Florida"))  # Output: go with you to Florida
print(replace_pronouns("I had my own castle"))  # Output: I had your own castle
