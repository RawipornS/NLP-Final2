# สร้างเทมเพลตสำหรับแสดงข้อความบอท
bot_template = "BOT : {0}"

# กำหนดตัวแปรสำหรับชื่อบอทและสภาพอากาศ
name = "Bot"  # ชื่อของบอท
weather = "cloudy"  # สภาพอากาศวันนี้

# พจนานุกรม responses เก็บคู่คำถาม-คำตอบ
responses = {
    "what's your name?": "my name is {0}".format(name),  # ตอบกลับชื่อของบอท
    "what's today's weather?": "the weather is {0}".format(weather),  # ตอบกลับสภาพอากาศ
    "default": "default message"  # ข้อความตอบกลับเริ่มต้น หากไม่มีคำตอบที่ตรงกัน
}

# ฟังก์ชัน respond ใช้ตรวจสอบและตอบกลับข้อความผู้ใช้
def respond(message):
    # ตรวจสอบว่าข้อความตรงกับคำถามในพจนานุกรมหรือไม่
    if message in responses:
        bot_message = responses[message]  # หากตรง ให้ดึงคำตอบจาก responses
    else:
        bot_message = responses["default"]  # หากไม่ตรง ให้ใช้ข้อความเริ่มต้น (default)
    return bot_message  # คืนค่าข้อความที่บอทจะตอบ

# ฟังก์ชัน send_message สำหรับส่งข้อความไปยังบอท
def send_message(message):
    # เรียกฟังก์ชัน respond เพื่อตอบกลับข้อความผู้ใช้
    response = respond(message)
    # แสดงผลข้อความของบอทโดยใช้เทมเพลต bot_template
    print(bot_template.format(response))

# เริ่มต้นการสนทนาโดยแสดงข้อความจากบอท
print(bot_template.format("Hi!"))  # พิมพ์คำว่า "Hi!" จากบอท
# รับข้อความจากผู้ใช้
value = input("USER : ")  # รับข้อความจากผู้ใช้
# ส่งข้อความไปยังบอทเพื่อตอบกลับ
send_message(value)  # เรียกใช้ฟังก์ชัน send_message พร้อมข้อความที่ผู้ใช้ส่งมา
