import re  # นำเข้าไลบรารี Regular Expressions สำหรับการตรวจสอบรูปแบบข้อความ

# กำหนดพจนานุกรม 'keywords' เก็บคำสำคัญสำหรับแต่ละ intent
keywords = {
    'greet': ['hello', 'hi', 'hey'],  # คำทักทาย
    'goodbye': ['bye', 'farewell'],  # คำบอกลา
    'thankyou': ['thank', 'thx']  # คำขอบคุณ
}

# สร้าง patterns สำหรับแต่ละ intent โดยใช้คำสำคัญจาก keywords
patterns = {intent: re.compile('|'.join(words)) for intent, words in keywords.items()}

# กำหนดพจนานุกรม 'responses' เก็บคำตอบสำหรับแต่ละ intent
responses = {
    'greet': 'Hello you! :)',
    'goodbye': 'goodbye for now',
    'thankyou': 'You are very welcome',
    'default': 'Default message'
}

# ฟังก์ชัน match_intent() ตรวจสอบว่าข้อความจากผู้ใช้ตรงกับ intent ใด
def match_intent(message):
    matched_intent = None  # เริ่มต้นด้วย intent เป็น None
    for intent, pattern in patterns.items():
        # ตรวจสอบว่ารูปแบบ pattern ตรงกับข้อความจากผู้ใช้หรือไม่
        if pattern.search(message):
            matched_intent = intent  # ถ้าตรงกัน ให้เก็บ intent ที่ตรงกัน
            break  # ออกจากลูปเมื่อพบ intent ที่ตรงกัน
    return matched_intent  # คืนค่า intent ที่พบ

# ฟังก์ชัน respond() เพื่อตอบกลับข้อความจากผู้ใช้ตาม intent
def respond(message):
    # เรียกใช้ match_intent() เพื่อตรวจสอบ intent ของข้อความผู้ใช้
    intent = match_intent(message)
    # ถ้า intent อยู่ใน responses จะใช้คำตอบของ intent นั้น
    key = "default"
    if intent in responses:
        key = intent
    return responses[key]  # คืนค่าคำตอบที่ตรงกับ intent

# สร้างเทมเพลตสำหรับการแสดงข้อความบอทและผู้ใช้
bot_template = "BOT : {0}"
user_template = "USER : {0}"

# ฟังก์ชัน send_message() สำหรับส่งข้อความจากผู้ใช้และรับคำตอบจากบอท
def send_message(message):
    # แสดงข้อความจากผู้ใช้
    print(user_template.format(message))
    # เรียกฟังก์ชัน respond() เพื่อรับคำตอบจากบอท
    response = respond(message)
    # แสดงข้อความตอบกลับจากบอท
    print(bot_template.format(response))

# ทดสอบการทำงานด้วยข้อความต่างๆ
send_message("hello!")  # ทดสอบข้อความทักทาย
send_message("bye byeee")  # ทดสอบข้อความบอกลา
send_message("thanks very much!")  # ทดสอบข้อความขอบคุณ
