# สร้างเทมเพลตสำหรับข้อความบอทและผู้ใช้ เพื่อใช้ในการแสดงผล
bot_template = "BOT : {0}"  # เทมเพลตสำหรับข้อความบอท
user_template = "USER : {0}"  # เทมเพลตสำหรับข้อความผู้ใช้

# สร้างพจนานุกรม responses ที่เก็บคู่คำถามและคำตอบของบอท
responses = {"what's your name?": "my name is EchoBot",  # ตอบกลับคำถาม "what's your name?"
            "what's the weather today?": "it's sunny!"}  # ตอบกลับคำถาม "what's the weather today?"

# ฟังก์ชัน respond ใช้สำหรับตรวจสอบว่าข้อความที่ผู้ใช้ส่งมาตรงกับคำถามในพจนานุกรม responses หรือไม่
def respond(message):
    if message in responses:  # ถ้าข้อความมีอยู่ใน responses
        return responses[message]  # คืนค่าคำตอบจาก responses ตามคำถามที่ตรงกัน

# เรียกใช้ฟังก์ชัน respond ด้วยคำถาม "what's your name?" เพื่อดูว่าฟังก์ชันทำงานได้อย่างถูกต้องหรือไม่
respond("what's your name?")

# ฟังก์ชัน respond อีกแบบหนึ่ง ใช้สำหรับตอบกลับข้อความของผู้ใช้โดยบอกว่าบอทได้ยินอะไร
def respond(message):
    bot_message = "I can hear you! you said: " + message  # สร้างข้อความตอบกลับโดยบอกว่าบอทได้ยินข้อความของผู้ใช้
    return bot_message  # คืนค่าข้อความบอท

# ฟังก์ชัน send_message ใช้สำหรับรับข้อความจากผู้ใช้และตอบกลับโดยใช้ฟังก์ชัน respond
def send_message():
    while True:  # ใช้ลูป while เพื่อให้ผู้ใช้สามารถส่งข้อความหลายๆ ครั้งได้
        message = input("USER: ")  # รับข้อความจากผู้ใช้
        
        if message.lower() == 'bye':  # ถ้าผู้ใช้พิมพ์ 'bye' ให้บอทกล่าวคำลาและออกจากลูป
            print("BOT: Goodbye!")  # พิมพ์ข้อความลา
            break  # ออกจากลูป
        
        response = respond(message)  # เรียกใช้ฟังก์ชัน respond เพื่อสร้างข้อความตอบกลับ
        
        print(bot_template.format(response))  # แสดงข้อความบอทโดยใช้เทมเพลต bot_template

# เรียกใช้ฟังก์ชัน send_message เพื่อเริ่มการสนทนากับผู้ใช้
send_message()
