import random

# สร้างเทมเพลตสำหรับการแสดงข้อความของบอทและผู้ใช้
bot_template = "BOT : {0}"
user_template = "USER : {0}"

# รายการคำตอบที่บอทจะสุ่มเลือกเพื่อตอบกลับ
responses = ["tell me more!", "why do you think that?"]

# ฟังก์ชัน respond ที่จะสุ่มตอบคำตอบจาก responses โดยตรง
def respond(message):
    return random.choice(responses)  # สุ่มเลือกคำตอบจาก responses

# ฟังก์ชันสำหรับการสนทนากับบอท
def send_message():
    while True:
        message = input("USER: ")  # รับข้อความจากผู้ใช้

        if message.lower() == 'bye':  # ถ้าผู้ใช้พิมพ์ว่า 'bye' ให้บอทกล่าวลาและจบการทำงาน
            print("BOT: Goodbye!")
            break  # ออกจากลูป

        response = respond(message)  # สุ่มเลือกคำตอบจาก responses
        print(bot_template.format(response))  # แสดงผลคำตอบของบอท

# เริ่มการสนทนากับบอท
send_message()
