import random  # นำเข้าไลบรารี random สำหรับสุ่มเลือกคำตอบ

# พจนานุกรม responses เก็บคำตอบที่เป็นไปได้สำหรับ statement, question และ default กรณี
responses = {
    'statement': [
        'Tell me more!',  # คำตอบที่เป็นไปได้สำหรับข้อความทั่วไป (statement)
        'Why do you think that?', 
        'How long have you felt this way?', 
        'I find that extremely interesting.', 
        'Can you back that up?', 
        'Oh wow!', 
        ':)'
    ],
    'question': [
        "I don't know :(",  # คำตอบที่เป็นไปได้สำหรับคำถาม
        'You tell me!'
    ],
    'default': [
        "I'm not sure I understand.",  # คำตอบเริ่มต้นเมื่อไม่เข้าใจข้อความ
        "Could you elaborate on that?"
    ]
}

# สร้างเทมเพลตสำหรับการแสดงข้อความของบอทและผู้ใช้
bot_template = "BOT : {0}"
user_template = "USER : {0}"

# ฟังก์ชัน get_response สำหรับการตอบกลับโดยพิจารณาจากข้อความที่เป็นคำถามหรือคำกล่าว
def get_response(message):
    """
    Generates a response based on whether the message is a question or statement.
    """
    message = message.strip().lower()  # ตัดช่องว่างและเปลี่ยนข้อความให้เป็นตัวพิมพ์เล็กทั้งหมด

    if message.endswith('?'):  # ถ้าข้อความลงท้ายด้วยเครื่องหมายคำถาม
        # ถ้าเป็นคำถาม ให้เลือกตอบจาก responses หมวด 'question'
        response = random.choice(responses.get("question", responses["default"]))
    elif message:  # ถ้าข้อความเป็นประโยคทั่วไป (ไม่ว่างเปล่าและไม่ใช่คำถาม)
        # ถ้าเป็นข้อความทั่วไป ให้เลือกตอบจาก responses หมวด 'statement'
        response = random.choice(responses.get("statement", responses["default"]))
    else:  # ถ้าเป็นข้อความว่างเปล่า
        # ให้กระตุ้นให้ผู้ใช้พิมพ์อะไรบางอย่าง
        response = "Please say something so I can respond."

    return response  # คืนค่าข้อความที่บอทตอบ

# ฟังก์ชัน send_message สำหรับการจัดการวงสนทนา
def send_message():
    """
    Handles the chat loop, taking user input and responding accordingly.
    """
    # แสดงข้อความทักทายเริ่มต้นของบอท
    print(bot_template.format("Hello! I'm ChatBot. How can I assist you today?"))

    while True:  # ลูปเพื่อให้ผู้ใช้สามารถพิมพ์ข้อความได้หลายครั้ง
        user_input = input(user_template.format(""))  # รับข้อความจากผู้ใช้

        if user_input.lower() == "bye":  # ถ้าผู้ใช้พิมพ์ 'bye'
            # แสดงข้อความอำลาและจบการทำงานของบอท
            print(bot_template.format("Goodbye! Have a great day!"))
            break  # ออกจากลูป

        # เรียกใช้ฟังก์ชัน get_response เพื่อหาคำตอบจากข้อความผู้ใช้
        response = get_response(user_input)
        # แสดงข้อความตอบกลับจากบอท
        print(bot_template.format(response))

# เริ่มต้นการทำงานของแชทบอท
send_message()
