import random

# สร้างเทมเพลตสำหรับการแสดงข้อความบอท
bot_template = "BOT : {0}"

# กำหนดตัวแปรสำหรับชื่อบอทและสภาพอากาศ
name = "Bot"  # ชื่อของบอท
weather = "cloudy"  # สภาพอากาศวันนี้

# พจนานุกรม responses เก็บคำถามและคำตอบเป็นรายการ (list)
responses = {
    "what's your name?": [  # คำถามเกี่ยวกับชื่อบอท
        "my name is {0}".format(name),  # คำตอบที่ 1
        "they call me {0}".format(name),  # คำตอบที่ 2
        "I am {0}".format(name)  # คำตอบที่ 3
    ],
    "what's today's weather?": [  # คำถามเกี่ยวกับสภาพอากาศ
        "the weather is {0}".format(weather),  # คำตอบที่ 1
        "it's {0} today".format(weather)  # คำตอบที่ 2
    ],
    "default": ["default message"]  # ข้อความเริ่มต้น หากคำถามไม่ตรงกับในพจนานุกรม
}

# ฟังก์ชัน respond สำหรับตอบกลับข้อความของผู้ใช้
def respond(message):
    if message in responses:  # ตรวจสอบว่าข้อความของผู้ใช้ตรงกับคำถามใน responses หรือไม่
        bot_message = random.choice(responses[message])  # สุ่มเลือกคำตอบจากรายการคำตอบที่ตรงกัน
    else:
        bot_message = random.choice(responses["default"])  # ถ้าไม่ตรง เลือกข้อความจาก "default"
    return bot_message  # คืนค่าข้อความที่บอทจะตอบ

# ฟังก์ชัน send_message สำหรับส่งข้อความไปยังบอท
def send_message():
    while True:  # วนลูปเพื่อให้ผู้ใช้สามารถส่งข้อความได้หลายครั้ง
        message = input("USER: ")  # รับข้อความจากผู้ใช้

        if message.lower() == 'bye':  # ถ้าผู้ใช้พิมพ์ว่า 'bye' ให้บอทกล่าวลา
            print("BOT: Goodbye!")
            break  # ออกจากลูป

        response = respond(message)  # เรียกฟังก์ชัน respond เพื่อตอบกลับข้อความของผู้ใช้

        print(bot_template.format(response))  # แสดงผลลัพธ์ข้อความจากบอท

# เริ่มการสนทนากับบอท
send_message()
