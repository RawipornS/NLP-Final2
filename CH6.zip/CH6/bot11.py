import re  # นำเข้าโมดูล re สำหรับใช้ Regular Expressions

# ฟังก์ชัน match_rule() ทำหน้าที่จับคู่ข้อความผู้ใช้กับรูปแบบในพจนานุกรม rules
def match_rule(message):
    # กำหนดกฎในพจนานุกรม rules โดยใช้ RegEx สำหรับจับคู่รูปแบบข้อความต่างๆ
    rules = {
        'do you remember (.*)': 'Did you think I would forget {0}?',
        'do you think (.*)': 'if {0}? Absolutely.',
        'I want (.*)': 'What would it mean if you got {0}?',
        'what if (.*)': "Do you really think it's likely that {0}?"
    }
    
    # วนลูปตรวจสอบข้อความผู้ใช้กับแต่ละรูปแบบที่กำหนดใน rules
    for pattern in rules:
        # ใช้ re.match เพื่อจับคู่รูปแบบ RegEx กับข้อความผู้ใช้
        if re.match(pattern, message):
            # ดึงข้อความที่ตรงกับรูปแบบด้วย re.findall และจัดเก็บเป็น phrase
            phrase = re.findall(pattern, message)[0]
            # คืนค่าคำตอบที่ตรงกับกฎและ phrase ที่ตรงกับข้อความ
            return rules[pattern], phrase
    # ถ้าไม่มีรูปแบบไหนตรงกัน คืนค่า None
    return None, None

# ฟังก์ชัน replace_pronouns สำหรับการแทนที่สรรพนามใน phrase
def replace_pronouns(phrase):
    phrase = phrase.lower()  # แปลงข้อความให้เป็นตัวพิมพ์เล็ก
    if 'me' in phrase:
        return phrase.replace('me', 'you')  # แทนที่ 'me' ด้วย 'you'
    if 'my' in phrase:
        return phrase.replace('my', 'your')  # แทนที่ 'my' ด้วย 'your'
    if 'your' in phrase:
        return phrase.replace('your', 'my')  # แทนที่ 'your' ด้วย 'my'
    if 'you' in phrase:
        return phrase.replace('you', 'me')  # แทนที่ 'you' ด้วย 'me'
    return phrase  # ถ้าไม่มีการแทนที่ คืนค่า phrase เดิม

# ฟังก์ชัน respond() ทำหน้าที่ตอบกลับผู้ใช้โดยเรียกใช้ match_rule และ replace_pronouns
def respond(message):
    # เรียก match_rule เพื่อตรวจสอบว่าข้อความผู้ใช้ตรงกับรูปแบบไหน
    response, phrase = match_rule(message)
    
    # ถ้าพบคำตอบและคำตอบมี '{0}' ให้แทนที่ phrase ลงในคำตอบ
    if response and '{0}' in response:
        # เรียก replace_pronouns เพื่อแทนที่สรรพนามใน phrase
        phrase = replace_pronouns(phrase)
        # ใช้ .format เพื่อแทนที่ phrase ในคำตอบ
        response = response.format(phrase)
    
    return response  # คืนค่าคำตอบที่บอทจะตอบกลับ

# ฟังก์ชัน send_message() สำหรับจำลองการสนทนากับผู้ใช้
def send_message(message):
    # แสดงข้อความจากผู้ใช้
    print(f'User: {message}')
    # แสดงคำตอบของบอทโดยเรียกใช้ฟังก์ชัน respond
    print(f'Bot: {respond(message)}\n')

# ทดสอบการทำงานของบอทด้วยข้อความต่างๆ
send_message("do you remember my last birthday")  # ตัวอย่างการถามเกี่ยวกับความทรงจำ
send_message("do you think humans should be worried about AI")  # ตัวอย่างการถามความคิดเห็น
send_message("I want a robot friend")  # ตัวอย่างการถามเกี่ยวกับความต้องการ
send_message("what if you could be anything you wanted")  # ตัวอย่างการถามแบบสมมติ
