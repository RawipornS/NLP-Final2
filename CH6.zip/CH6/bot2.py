# สร้างเทมเพลตสำหรับแสดงผลข้อความบอทและผู้ใช้
bot_template = "BOT : {0}"  # เทมเพลตสำหรับข้อความบอท
user_template = "USER : {0}"  # เทมเพลตสำหรับข้อความผู้ใช้

# สร้างพจนานุกรม responses ที่เก็บคู่คำถามและคำตอบที่บอทจะตอบกลับ
responses = {"what's your name?": "my name is EchoBot",  # ตอบกลับคำถาม "what's your name?"
             "what's the weather today?": "it's sunny!"}  # ตอบกลับคำถาม "what's the weather today?"

# ฟังก์ชัน respond ใช้ในการจับคู่ข้อความของผู้ใช้กับพจนานุกรม responses และคืนค่าคำตอบ
def respond(message):
    if message in responses:  # ตรวจสอบว่าข้อความที่ผู้ใช้ส่งมาตรงกับคำถามใน responses หรือไม่
        return responses[message]  # ถ้าตรง ให้คืนค่าคำตอบจาก responses

# ทดสอบฟังก์ชัน respond ด้วยการส่งคำถาม "what's your name?"
respond("what's your name?")

# ฟังก์ชัน send_message ใช้สำหรับรับข้อความจากผู้ใช้และตอบกลับตามฟังก์ชัน respond
def send_message():
    while True:  # วนลูปเพื่อให้สามารถส่งข้อความได้หลายครั้ง
        message = input("USER: ")  # รับข้อความจากผู้ใช้
        
        # ถ้าผู้ใช้พิมพ์ 'bye' บอทจะกล่าวคำลาและออกจากลูป
        if message.lower() == 'bye':  # ตรวจสอบว่าผู้ใช้พิมพ์ 'bye' หรือไม่
            print("BOT: Goodbye!")  # แสดงข้อความลา
            break  # ออกจากลูป

        # เรียกใช้ฟังก์ชัน respond เพื่อหาคำตอบจากข้อความของผู้ใช้
        response = respond(message)

        # แสดงผลข้อความตอบกลับจากบอท โดยใช้เทมเพลต bot_template
        print(bot_template.format(response))

# เรียกใช้ฟังก์ชัน send_message เพื่อเริ่มต้นการสนทนา
send_message()
